package com.crudoperation.mongoTemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
