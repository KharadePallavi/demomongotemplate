package com.crudoperation.mongoTemplate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Service;

import com.crudoperation.mongoTemplate.dao.EmployeeRepository;
import com.crudoperation.mongoTemplate.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;

	
	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public List<Employee> findByName(String name) {
		// TODO Auto-generated method stub
		return employeeRepository.findByName(name);
	}

	@Override
	public List<Employee> findByDept(String department) {
		// TODO Auto-generated method stub
		return employeeRepository.findByDept(department);
	}

	@Override
	public List<Employee> saveAll(List<Employee> employee) {
		// TODO Auto-generated method stub
		return employeeRepository.saveAll(employee);
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		employeeRepository.deleteAll();
	}

	@Override
	public List<Employee> findByNameAndDept(String name, String department) {
		// TODO Auto-generated method stub
		return employeeRepository.findByNameAndDept(name,department);
	}

	@Override
	public List<Employee> findByAgeGreaterThanAndLessThan(int minage, int maxage) {
		// TODO Auto-generated method stub
		return employeeRepository.findByAgeGreaterThanAndLessThan(minage,maxage);
	}

	@Override
	public List<Employee> findByNameOrderByDepartment(String name) {
		// TODO Auto-generated method stub
		
		
		return employeeRepository.findByNameOrderByDepartment(name);
	}

	@Override
	public List<Employee> findByNameStartingWith(String name) {
		// TODO Auto-generated method stub
		return employeeRepository.findByNameStartingWith(name);
	}

	@Override
	public List<Employee> findByAge(int age) {
		// TODO Auto-generated method stub
		return employeeRepository.findByAge(age);
	}
	
	
	
	
	
	
}
