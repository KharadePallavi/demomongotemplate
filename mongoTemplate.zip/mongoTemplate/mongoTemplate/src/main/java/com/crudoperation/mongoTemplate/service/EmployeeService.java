package com.crudoperation.mongoTemplate.service;

import java.util.List;

import com.crudoperation.mongoTemplate.model.Employee;


public interface EmployeeService {


	List<Employee> findAll();

	List<Employee> findByName(String name);

	List<Employee> findByDept(String department);

	List<Employee> saveAll(List<Employee> employee);

	void deleteAll();

	
	List<Employee> findByNameOrderByDepartment(String name);
	
	List<Employee> findByNameAndDept(String name, String department);

	List<Employee> findByAgeGreaterThanAndLessThan(int minage, int maxage);

	List<Employee> findByNameStartingWith(String name);

	List<Employee> findByAge(int age);

	

}
