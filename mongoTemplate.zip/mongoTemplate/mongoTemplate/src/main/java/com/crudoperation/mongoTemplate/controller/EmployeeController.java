package com.crudoperation.mongoTemplate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crudoperation.mongoTemplate.model.Employee;
import com.crudoperation.mongoTemplate.service.EmployeeService;

import ch.qos.logback.core.joran.conditional.ElseAction;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

//	@PostMapping("/save")
//	public List<Employee> save(@RequestBody List<Employee> employee) {
//		return employeeService.saveAll(employee);
//	}

	@PostMapping("/save")
	public ResponseEntity<List<Employee>> save(@RequestBody List<Employee> employee){
		List<Employee> employees= employeeService.saveAll(employee);
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}
	
	@GetMapping("/findall")
	public ResponseEntity<List<Employee>> findAll() {
		List<Employee> employees=  employeeService.findAll();
		if(employees!=null) {
		return new  ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}else {
		return new ResponseEntity<>(employees,HttpStatus.NOT_FOUND);
	
	}
	}
	
	@DeleteMapping("/deleteall")
	public void deleteAll() {
		employeeService.deleteAll();
	}

	@GetMapping("/findbyname/{name}")
	List<Employee> findAll(@PathVariable(value = "name") String name) {
		return employeeService.findByName(name);

	}

	@GetMapping("/findbydept/{department}")
	List<Employee> findByDept(@PathVariable(value = "department") String department) {
		return employeeService.findByDept(department);

	}
	
	@GetMapping("/findage/{age}")
	public List<Employee> findage(@PathVariable int age){
		return employeeService.findByAge(age);
	}

	@GetMapping("/findbynandd/{name}/{department}")
	public List<Employee> findByNameAndDept(@PathVariable(value = "name") String name,
			@PathVariable(value = "department") String department) {
		return employeeService.findByNameAndDept(name, department);

	}

	
	//Not done giving the null output//
	@GetMapping("/findbyage")
	public List<Employee> findByAgeGreaterThanAndLessThan(@RequestParam int minage,
			@RequestParam int maxage) {
		return employeeService.findByAgeGreaterThanAndLessThan(minage, maxage);
	}

	
	@GetMapping("/findbynameorderbydept/{name}")
	List<Employee> findbynameorderbydept(@PathVariable(value = "name") String name) {
		org.springframework.data.mongodb.core.query.Query query = new org.springframework.data.mongodb.core.query.Query();
		query.addCriteria(Criteria.where("name").is(name));

		return employeeService.findByNameOrderByDepartment(name);

	}

	
	@GetMapping("/findbynamestartingwith")
	List<Employee> findByNameStartingWith(@RequestParam(name = "name") String name) {
		return employeeService.findByNameStartingWith(name);

	}
	
	
}
