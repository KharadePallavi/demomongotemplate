package com.crudoperation.mongoTemplate.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.crudoperation.mongoTemplate.model.Employee;

@Repository
public interface EmployeeRepository extends MongoRepository<Employee, String> {
	
	//Using the Query Annotation perform the searching operation 

	// To find by name using query annotation along with that we can modify the
	// search results.
	//	@Query(value = "{'name': ?0}", fields = "{'lastName': 1, 'age': 1 }" )
	//	List<Employee> findByName(String name);

	
	@Query("{'department': ?0}")
	List<Employee> findByDept(String department);

	
    //the case insensitive
	@Query("{'name':{'$regex': '?0'} }")
	//@Query("{'name': {'$regex': '?0', '$options':'i'} }")
	List<Employee> findByName(String name);

	
	//Find the employee using name and the department
	@Query("{'name': {'$regex': '?0' }, 'department': {'$regex': '?1'} }")
	List<Employee> findByNameAndDept(String name, String department);
	
	
	@Query("{'age': { $gt: ?0 , $lt: ?1 } }")
	List<Employee> findByAgeGreaterThanAndLessThan(int minage, int maxage);
	
	
	
	
	
	
	
	//Using the Method we can perform the searching operation 
	List<Employee> findByNameOrderByDepartment(String name);


	List<Employee> findByNameStartingWith(String name);

    @Query(value= "{'age': {$gte: ?0}}")
	List<Employee> findByAge(int age);


	
	
	
}
